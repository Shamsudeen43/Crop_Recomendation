# Muhammad Shamsudeen Yakubu — AI Crop Recommendation

## Dataset
- 5,000 observations
- 7 numerical inputs: N, P, K, temperature, humidity, pH, rainfall
- 1 categorical input: soil texture
- 10 crop classes: beans, cassava, guinea_corn, maize, orange, pepper, rice, soybean, tomatoes, yam

## Modeling
Two classifiers were benchmarked with a stratified 80/20 holdout and 5-fold Stratified K-Fold cross-validation:
1. Random Forest
2. Logistic Regression

The selected model is **Random Forest**, based on test Macro F1.

### Key EDA findings
- No missing values were found.
- Class distribution is reasonably broad, although cassava is the smallest class at about 6.0%.
- IQR screening flags rainfall and pH observations as statistical outliers; they were retained because agricultural extremes can be meaningful rather than automatically discarded.
- Strongest numerical correlation: P vs humidity (approximately -0.79).

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deployment
For Streamlit Community Cloud, upload this project to a GitHub repository and deploy `app.py`.
The repository must contain:
- `app.py`
- `requirements.txt`
- `artifacts/crop_recommender.joblib`

## Important
The reported accuracy is extremely high on this dataset. This should be discussed transparently in the presentation: verify against external/field data before treating the model as production-ready.
